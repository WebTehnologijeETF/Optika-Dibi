<!DOCTYPE html>
	<html> 
	<head>

		
		<meta charset="utf-8">
		
		<title>Optičke usluge | Mjerenje vida | Izrada naočala | Cijena | Prodaja | Akcija</title>
	
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="meniSkripta.js"></script>
		<script src="jsFile.js"></script>
<script src="ucitavanje.js"></script>
<?php include 'novosti.php';?>
	</head>
	
<body id ="main" >
<header class="izbornik">
<img src="logo.jpg" alt="sk">



<ul id="sddm">
     <li><a 
        onmouseover="mopen('m1')" 
        onmouseout="mclosetime()"
		onclick="Load('Naslovnica.php');">Naslovnica</a>
        <div id="m1" 
            onmouseover="mcancelclosetime()" 
            onmouseout="mclosetime()">
        <a  onclick="Load('Naslovnica.php');">Dioptrijski okviri</a>
        <a  onclick="Load('Naslovnica.php');">Oko 30% - 60% popusta</a>
        <a  onclick="Load('Naslovnica.php');">Kontaktne leće i otopine</a>
		<a onclick="Load('Naslovnica.php');">Varilux 1+1</a>
        </div>
    </li>
    <li><a  onclick="Load('ONama.html');" >O nama</a></li>
    <li><a onclick="Load('Katalog.html');"
	 onmouseover="mopen('m2')" 
        onmouseout="mclosetime()">Katalog proizvoda</a>
	       <div id="m2" 
            onmouseover="mcancelclosetime()" 
            onmouseout="mclosetime()">
        <a  onclick="Load('Katalog.html');">Dioptrijski okviri</a>
        <a onclick="Load('Katalog.html');">Dioptrijske leće</a>
        <a  onclick="Load('Katalog.html');">Sunčane naočale</a>
        <a  onclick="Load('Katalog.html');"> >Accessories </a>
        </div>
	
	
	</li>
    <li><a  onclick="Load('Usluge.html');">Usluge</a></li>
    <li><a  onclick="Load('Kontakt.php'); ">Kontakt</a></li>
</ul>
<div style="clear:both"></div>
<div class="header_underline"> </div>
</header>

<div class="podloga" >
	<div class="dodatna"><br><br>
	<em>Ključ 20-godišnjeg uspjeha Jo-Jo optike je briga za klijenta, profesionalnost, individualni pristup, ljubaznost i raznolika ponuda te cijene pristupačne svakom klijentu.</em>
	<br>
<div class="lijeviKontakt">
<div class="scroll2">

						
							
							
										<h2 ><a href="caleks1.jpg"  title="Dioptrijski okviri">Dioptrijski okviri</a></h2>
										

<img src="caleks1.jpg" title="Dioptrijski okviri" alt="hg">
	<br><strong>Autor: </strong>Gazetić Elma<br>
	<strong>Datum objave: </strong>19.03.2015<br>

									<p>U ponudi imamo i veliki izbor dioptrijskih okvira i sunčanih naočala  <br>vodećih
										robnih marki koje potpisuju poznati modni kreatori:<br>
										Burberry Carrere, Emporio Armani, Gucci, MaxMara, Persol...<br>
				<details >
                <summary>Detaljnije</summary>
                Sav izbor naših proizvoda imate na linku : <a href="Katalog.html">Katalog proizvoda</a> 
            </details>
														
										<h2 ><a href="caleks2.png"  title="Od 30% - 60% popusta">Od 30% - 60% popusta</a></h2>
										

<img src="caleks2.png" alt="Od 30% - 60% popusta" title="Od 30% - 60% popusta"  />
<br><strong>Autor: </strong>Strojil Edin Stroja<br>
	<strong>Datum objave: </strong>15.03.2015<br>
										<p>Nudimo Vam popust od 30% - 60% na određeni asortiman!
				<details >
                <summary>Detaljnije</summary>
                Više o ovim  : <a href="#">Popusti</a>
            </details>
										<h2 ><a href="caleks3.jpg"  title="Kontaktne leće i otopine">Kontaktne leće i otopine</a></h2>
										

<img src="caleks3.jpg" alt="Kontaktne leće i otopine" title="Kontaktne leće i otopine" />
<br><strong>Autor: </strong>Emina Huskić<br>
	<strong>Datum objave: </strong>15.03.2015<br>
									<p>Iz ponude kontaktnih leća možete odabrati: dnevne leće, <br>
									mjesečne leće, tromjesečne leće, godišnje leće; leće za astigmatizam <br>
									i multifokalne leće, leće u boji te otopine za održavanje leća... <br>
											<details >
                <summary>Detaljnije</summary>
                Sav izbor naših proizvoda imate na linku : <a href="Katalog.html">Katalog proizvoda</a>
            </details>	
										<h2 ><a href="caleks4.png"  title="Varilux 1+1">Varilux 1+1</a></h2>
										

<img src="caleks4.png" alt="Varilux 1+1" title="Varilux 1+1"  />
<br><strong>Autor: </strong>Esma Musić<br>
	<strong>Datum objave: </strong>14.03.2015<br>
										<p>Prekratke ruke, presitna slova, previše pari naočala  <br>
										u isto vrijeme... niste jedini. Riječ je o prirodnom procesu  <br>
										starenja oka, ili prezbiopiji.
										<br> Varilux progresivne naočalne leće...
												<details >
                <summary>Detaljnije</summary>
                Sav izbor naših proizvoda imate na linku : <a href="Katalog.html">Katalog proizvoda</a>
            </details>	


	</div></div>
	<div class="desniKontakt">
						
							
			<ul>


				<li>	stručno savjetovanje i mjerenje vida</li>
					<li>		servis svih vrsta naočala (popravka naočala)</li>
					<li>		mogućnost plaćanja gotovinom i karticama</li>
						
						
						
						<li>	stručna pomoć pri odabiru okvira i  leća</li>
							<li>	kontaktne leće i otopine</li>
							
					<li>	primamo recepte HZZO-a</li>
				

					<li>kvalitetna i brza izrada naočala </li>
					<li>	velik izbor sunčanih i dioptrijskih okvira</li>
						<li>	najbolji omjer cijene i kvalitete</li>
				

					</ul>	

			
</div>



<p>

</div></div>

<footer id="Copy">
    Copyright &copy; Ediba Žugor 2015.
</footer>

</body>